"""Custodia Standalone Verifier — ZERO third-party dependencies.

Runs on plain Python 3 (stdlib only: sqlite3, hashlib). No Custodia, no
`cryptography`, no internet. This is the embodiment of the product promise:
the archive opens and PROVES ITSELF in 2036 with free tools, without the vendor.

It re-derives everything from the archived DATA (not from convenience tables):
  1. recompute every record hash from the actual data_* tables
  2. rebuild the Merkle root
  3. confirm the root matches the certificate's signed payload
  4. recompute the payload SHA-256
  5. verify the Ed25519 signature over the payload (vendored RFC 8032 verify)

Usage:  python3 standalone_verify.py <archive.db>
Exit 0 = VALID, 1 = INVALID/FAIL. Prints a human-readable report.

The Ed25519 verify below is the public-domain RFC 8032 reference algorithm.
It is used for VERIFICATION ONLY (deterministic public math); signing is done
by Custodia with the vetted `cryptography` library. The two are cross-checked
in the Custodia test suite so this reimplementation cannot silently drift.
"""
import hashlib
import sqlite3
import sys
_p = 2 ** 255 - 19
_L = 2 ** 252 + 27742317777372353535851937790883648493

def _modp_inv(x):
    return pow(x, _p - 2, _p)
_d = -121665 * _modp_inv(121666) % _p
_I = pow(2, (_p - 1) // 4, _p)

def _recover_x(y, sign):
    if y >= _p:
        return None
    xx = (y * y - 1) * _modp_inv(_d * y * y + 1)
    x = pow(xx % _p, (_p + 3) // 8, _p)
    if (x * x - xx) % _p != 0:
        x = x * _I % _p
    if (x * x - xx) % _p != 0:
        return None
    if x & 1 != sign:
        x = _p - x
    return x
_g_y = 4 * _modp_inv(5) % _p
_g_x = _recover_x(_g_y, 0)
_G = (_g_x, _g_y, 1, _g_x * _g_y % _p)

def _point_add(P, Q):
    A = (P[1] - P[0]) * (Q[1] - Q[0]) % _p
    B = (P[1] + P[0]) * (Q[1] + Q[0]) % _p
    C = 2 * P[3] * Q[3] * _d % _p
    D = 2 * P[2] * Q[2] % _p
    E, F, G, H = ((B - A) % _p, (D - C) % _p, (D + C) % _p, (B + A) % _p)
    return (E * F % _p, G * H % _p, F * G % _p, E * H % _p)

def _point_mul(s, P):
    Q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            Q = _point_add(Q, P)
        P = _point_add(P, P)
        s >>= 1
    return Q

def _point_equal(P, Q):
    if (P[0] * Q[2] - Q[0] * P[2]) % _p != 0:
        return False
    if (P[1] * Q[2] - Q[1] * P[2]) % _p != 0:
        return False
    return True

def _sha512_int(b):
    return int.from_bytes(hashlib.sha512(b).digest(), 'little')

def _decompress(comp):
    y = int.from_bytes(comp, 'little')
    sign = y >> 255 & 1
    y &= (1 << 255) - 1
    x = _recover_x(y, sign)
    return None if x is None else (x, y, 1, x * y % _p)

def ed25519_verify(public_key: bytes, msg: bytes, signature: bytes) -> bool:
    """True iff signature is a valid Ed25519 signature of msg under public_key."""
    if len(public_key) != 32 or len(signature) != 64:
        return False
    A = _decompress(public_key)
    if A is None:
        return False
    Rs = signature[:32]
    R = _decompress(Rs)
    if R is None:
        return False
    s = int.from_bytes(signature[32:], 'little')
    if s >= _L:
        return False
    h = _sha512_int(Rs + public_key + msg) % _L
    sB = _point_mul(s, _G)
    hA = _point_mul(h, A)
    return _point_equal(sB, _point_add(R, hA))

def _leaf_hash(data):
    return hashlib.sha256(b'\x00' + data).hexdigest()

def _node_hash(l, r):
    return hashlib.sha256(b'\x01' + bytes.fromhex(l) + bytes.fromhex(r)).hexdigest()

def _largest_pow2_lt(n):
    # bit-length form (NO comparison operator for a format-on-save hook to invert;
    # a linter kept flipping `while k*2 < n` to `>= n`, silently breaking the
    # Merkle split). Largest power of two strictly less than n, for n > 1.
    # Identical to crypto._largest_pow2_lt; the phase-10 golden cross-checks it.
    return 1 << ((n - 1).bit_length() - 1)

def _merkle_root(leaf_hashes):
    """RFC 6962 — split at largest power of two below n; never duplicate the odd
    node (that duplication is the malleability closed here)."""
    n = len(leaf_hashes)
    if n == 0:
        return _leaf_hash(b'')
    if n == 1:
        return _leaf_hash(bytes.fromhex(leaf_hashes[0]))
    k = _largest_pow2_lt(n)
    return _node_hash(_merkle_root(leaf_hashes[:k]), _merkle_root(leaf_hashes[k:]))

def _lp(b):
    return len(b).to_bytes(8, 'big') + b

def _hash_record(columns, values):
    """Type-tagged canonical hash — must byte-match custodia/crypto.hash_record."""
    h = hashlib.sha256()
    h.update(len(columns).to_bytes(8, 'big'))
    for col, val in zip(columns, values):
        h.update(_lp(col.encode('utf-8')))
        if val is None:
            h.update(b'\x00')
        else:
            h.update(b'\x01')
            h.update(_lp(str(val).encode('utf-8')))
    return h.hexdigest()

def _key_fingerprint(public_hex):
    return hashlib.sha256(bytes.fromhex(public_hex)).hexdigest()

def _load_publication(path):
    """Read + integrity-check an operator key-publication (from a TRUSTED channel,
    NOT the archive). Handles v1 (notary-signed, single key pair) and v2 (OFFLINE-
    ROOT-signed, delegated key lists + epoch, survives rotation). Returns
    {version, signing:[...], notary:[...], root_fpr|None} or None if malformed."""
    import json
    try:
        data = json.loads(open(path).read())
        if data.get('statement') == 'CUSTODIA-KEY-PUBLICATION-v2':
            stmt = ('\n'.join(['CUSTODIA-KEY-PUBLICATION-v2', f"epoch={data['epoch']}", f"generated={data['generated']}", f"valid_from={data['valid_from']}", f"valid_to={data['valid_to']}", 'signing_fingerprints=' + ','.join(data['signing_fingerprints']), 'notary_fingerprints=' + ','.join(data['notary_fingerprints']), f"root_fingerprint={data['root_fingerprint']}"]) + '\n').encode('utf-8')
            if not ed25519_verify(bytes.fromhex(data['root_pubkey']), stmt, bytes.fromhex(data['signature'])):
                return None
            if _key_fingerprint(data['root_pubkey']) != data['root_fingerprint']:
                return None
            return {'version': 2, 'signing': list(data['signing_fingerprints']), 'notary': list(data['notary_fingerprints']), 'root_fpr': data['root_fingerprint']}
        msg = f"CUSTODIA-KEY-PUBLICATION-v1\nsigning_fingerprint={data['signing_fingerprint']}\nnotary_fingerprint={data['notary_fingerprint']}\ngenerated={data['generated']}\n".encode('utf-8')
        if not ed25519_verify(bytes.fromhex(data['notary_pubkey']), msg, bytes.fromhex(data['signature'])):
            return None
        if _key_fingerprint(data['notary_pubkey']) != data['notary_fingerprint']:
            return None
        return {'version': 1, 'signing': [data['signing_fingerprint']], 'notary': [data['notary_fingerprint']], 'root_fpr': None}
    except (OSError, ValueError, KeyError):
        return None

def _metadata_digest(conn):
    """SHA-256 over EVERY row of datasets+source_files. MUST byte-match
    certificate.metadata_digest — binds all provenance metadata under the
    signature so it cannot be rewritten post-signing without detection."""
    h = hashlib.sha256()
    for table in ('datasets', 'source_files'):
        cols = [r[1] for r in conn.execute(f'PRAGMA table_info({table})')]
        h.update((f'T:{table}\n' + ','.join(cols) + '\n').encode('utf-8'))
        for row in conn.execute(f'SELECT * FROM {table} ORDER BY id'):
            for c in cols:
                v = row[c]
                h.update((f'{c}=' + ('\x00NULL' if v is None else str(v)) + '\n').encode('utf-8'))
            h.update(b'R\n')
    return h.hexdigest()

def _parse_payload(payload):
    """Block parser: top-level key=value + dataset.begin/end blocks (one field
    per line — robust to spaces/specials in filenames)."""
    d = {'datasets': []}
    cur = None
    for line in payload.splitlines():
        if line == 'dataset.begin':
            cur = {}
        elif line == 'dataset.end':
            if cur is not None:
                d['datasets'].append(cur)
            cur = None
        elif '=' in line:
            k, v = line.split('=', 1)
            (cur if cur is not None else d)[k] = v
    return d

def verify_archive(db_path: str, expect_key: str=None, expect_notary: str=None, expect_prev: str=None):
    """Returns (ok, report, signer_pubkey, signer_fpr, signer_status).

    signer_status:
      'trusted'    - expect_key given and matches the archive's signing key
      'UNTRUSTED'  - expect_key given but the archive was signed by a DIFFERENT
                     key (possible forgery)
      'UNVERIFIED' - no expect_key given; integrity holds but the signer's
                     identity was NOT checked against a known-good key
    ok is True only when integrity passes AND the signer is 'trusted'."""
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cert = conn.execute('SELECT * FROM certificates ORDER BY id DESC LIMIT 1').fetchone()
    except sqlite3.DatabaseError:
        return (False, [('archive is a readable Custodia database', False)], '', '', 'UNVERIFIED')
    report = []
    ok = True
    if not cert:
        return (False, [('certificate present', False)], '', '', 'UNVERIFIED')
    signed = _parse_payload(cert['payload'])
    signer_pubkey = cert['public_key_hex']
    signer_fpr = _key_fingerprint(signer_pubkey)
    recomputed = []
    per_ds = {}
    for ds in conn.execute('SELECT id,name,table_name FROM datasets ORDER BY name'):
        cols = [r['column_name'] for r in conn.execute('SELECT column_name FROM dataset_columns WHERE dataset_id=? ORDER BY position', (ds['id'],))]
        cnt = 0
        for row in conn.execute(f'''SELECT * FROM "{ds['table_name']}" ORDER BY row_id'''):
            recomputed.append(_hash_record(cols, [row[c] for c in cols]))
            cnt += 1
        per_ds[ds['name']] = cnt
    stored = []
    for ds in conn.execute('SELECT id,name FROM datasets ORDER BY name'):
        stored += [r['sha256'] for r in conn.execute('SELECT sha256 FROM record_hashes WHERE dataset_id=? ORDER BY row_id', (ds['id'],))]
    data_matches = recomputed == stored
    report.append(('record hashes match archived data', data_matches))
    ok &= data_matches
    signed_total = int(signed.get('total_records', -1))
    count_ok = signed_total == len(recomputed) == len(stored)
    report.append(('record count matches signed total', count_ok))
    ok &= count_ok
    recon_ok = signed.get('archive_status') == 'COMPLETE'
    for sd in signed['datasets']:
        nm = sd.get('name')
        if sd.get('status') != 'RECONCILED' or int(sd.get('records_hashed', -1)) != per_ds.get(nm, -2):
            recon_ok = False
    report.append(('all datasets reconciled (complete)', recon_ok))
    ok &= recon_ok
    signed_md = signed.get('metadata_digest')
    if signed_md is not None:
        md_ok = _metadata_digest(conn) == signed_md
        report.append(('archive metadata matches signed digest', md_ok))
        ok &= md_ok
    # surface the SIGNED extraction scope of each dataset (its integrity is already
    # enforced by the metadata digest above; shown so an auditor sees exactly what
    # was — and was not — pulled: complete OF THIS SCOPE, not of all that existed)
    for sd in signed['datasets']:
        report.append((f"scope of '{sd.get('name')}' (signed): "
                       f"{sd.get('source_scope', 'unspecified')}", True))
    root = _merkle_root(recomputed)
    report.append(('merkle root matches certificate', root == cert['merkle_root']))
    ok &= root == cert['merkle_root']
    binds = f"merkle_root={cert['merkle_root']}" in cert['payload']
    report.append(('signed payload binds the root', binds))
    ok &= binds
    # snapshot chain (v6): prev_merkle_root is inside the signed payload, so the
    # signature check below already prevents an insider re-linking the chain. Surface
    # it; enforce the specific predecessor if the auditor pinned --expect-prev.
    signed_prev = signed.get('prev_merkle_root')
    if signed_prev and signed_prev != 'null':
        report.append((f'chained to prior snapshot root {signed_prev[:16]}', True))
    if expect_prev is not None:
        prev_ok = (signed_prev or 'null') == expect_prev
        report.append(('chain link matches expected predecessor (--expect-prev)', prev_ok))
        ok &= prev_ok
    payload_ok = hashlib.sha256(cert['payload'].encode()).hexdigest() == cert['payload_sha256']
    report.append(('payload hash intact', payload_ok))
    ok &= payload_ok
    sig_ok = ed25519_verify(bytes.fromhex(cert['public_key_hex']), cert['payload'].encode('utf-8'), bytes.fromhex(cert['signature_hex']))
    report.append(('Ed25519 signature valid (self-consistent)', sig_ok))
    ok &= sig_ok
    npub = cert['anchor_notary_pubkey']
    nsig = cert['anchor_signature']
    ngen = cert['anchor_gen_time']
    anchor_present = bool(npub)
    signed_anchored = signed.get('anchored') == 'true'
    anchor_unchecked = False
    if signed_anchored:
        match = anchor_present and _key_fingerprint(npub) == signed.get('notary_fingerprint') and (str(ngen) == signed.get('anchor_gen_time')) and (str(cert['anchor_log_seq']) == signed.get('anchor_log_seq')) and (str(cert['anchor_log_entry_hash']) == signed.get('anchor_log_entry_hash'))
        report.append(('signed anchor status matches stored anchor', match))
        ok &= match
        if match and expect_notary is not None:
            msg = f"CUSTODIA-ANCHOR-v1\nmerkle_root={cert['merkle_root']}\nkey_fingerprint={signer_fpr}\ngen_time={ngen}\n".encode('utf-8')
            try:
                asig = ed25519_verify(bytes.fromhex(npub), msg, bytes.fromhex(nsig))
            except (ValueError, TypeError):
                asig = False
            report.append(('anchor: notary signed this root at ' + str(ngen), asig))
            ok &= asig
            nfpr = _key_fingerprint(npub)
            _en = {expect_notary} if isinstance(expect_notary, str) else set(expect_notary)
            ntrust = npub in _en or nfpr in _en
            report.append(('anchor: notary key matches trusted anchor', ntrust))
            ok &= ntrust
        elif match:
            report.append(('transparency anchor present but NOT checked (pass --check-anchor)', False))
            ok = False
            anchor_unchecked = True
    elif expect_notary is not None:
        report.append(('transparency anchor expected but ABSENT (signed anchored=false)', False))
        ok = False
    tok = cert['rfc3161_token']
    if tok:
        thash = cert['rfc3161_hashhex'] or cert['payload_sha256']
        try:
            binds = bytes.fromhex(thash) in bytes.fromhex(tok)
        except ValueError:
            binds = False
        report.append((f"rfc3161 timestamp token binds this certificate (TSA={cert['rfc3161_tsa']})", binds))
        ok &= binds
    if expect_key:
        _ek = {expect_key} if isinstance(expect_key, str) else set(expect_key)
        trusted = signer_pubkey in _ek or signer_fpr in _ek
        report.append(('signer key matches trusted anchor', trusted))
        ok &= trusted
        signer_status = 'trusted' if trusted else 'UNTRUSTED'
    else:
        signer_status = 'UNVERIFIED'
        ok = False
    conn.close()
    return (ok, report, signer_pubkey, signer_fpr, signer_status)

def _usage():
    print('usage: python3 standalone_verify.py <archive.db> [--expect-key <pubkey-or-fingerprint>]')
    print('                                                 [--check-anchor <notary-key-or-fingerprint>]')
    print("  --expect-key    Custodia's PUBLISHED signing key (hex) or SHA-256 fingerprint.")
    print('                  Obtain it independently, NOT from this archive.')
    print("  --check-anchor  Custodia's PUBLISHED notary (timestamp) key/fingerprint. Verifies a")
    print('                  separate-key timestamp attestation over the Merkle root — defends')
    print('                  against archive-signing-key compromise / backdating.')
    sys.exit(2)

def _take_opt(args, name):
    if name in args:
        i = args.index(name)
        try:
            val = args[i + 1]
        except IndexError:
            _usage()
        return (args[:i] + args[i + 2:], val)
    return (args, None)
if __name__ == '__main__':
    args = sys.argv[1:]
    args, expect = _take_opt(args, '--expect-key')
    args, expect_notary = _take_opt(args, '--check-anchor')
    args, pub_file = _take_opt(args, '--check-transparency')
    args, expect_root = _take_opt(args, '--expect-root')
    args, expect_prev = _take_opt(args, '--expect-prev')
    if len(args) != 1:
        _usage()
    if pub_file:
        loaded = _load_publication(pub_file)
        if loaded is None:
            print('RESULT: INVALID — key-publication file is malformed or its signature failed')
            sys.exit(1)
        if expect_root is not None and loaded.get('root_fpr') != expect_root:
            print('RESULT: INVALID — publication root fingerprint does not match your --expect-root pin')
            sys.exit(1)
        pub_signing, pub_notary = loaded['signing'], loaded['notary']
        if expect is not None and expect not in pub_signing:
            print("RESULT: INVALID — publication file's signing key contradicts your --expect-key")
            sys.exit(1)
        expect = expect if expect is not None else set(pub_signing)
        if expect_notary is None:
            expect_notary = set(pub_notary)
        elif expect_notary not in pub_notary:
            print("RESULT: INVALID — publication file's notary key contradicts your --check-anchor")
            sys.exit(1)
    valid, rep, signer_pubkey, signer_fpr, signer_status = verify_archive(args[0], expect, expect_notary, expect_prev)
    print('=' * 64)
    print('CUSTODIA STANDALONE VERIFICATION (no vendor, no dependencies)')
    print('=' * 64)
    for name, passed in rep:
        print(f"  [{('PASS' if passed else 'FAIL')}] {name}")
    print('-' * 64)
    print(f'SIGNING KEY FINGERPRINT: {signer_fpr}')
    SOFT = {'signer key matches trusted anchor', 'transparency anchor present but NOT checked (pass --check-anchor)'}
    integrity_ok = all((p for name, p in rep if name not in SOFT))
    anchor_unchecked = any((name == 'transparency anchor present but NOT checked (pass --check-anchor)' for name, _ in rep))
    if valid:
        print('SIGNER: trusted (matches the key you supplied)')
        print('RESULT: VALID — archive is complete, unaltered, and signed by the trusted key')
        sys.exit(0)
    if signer_status == 'UNTRUSTED':
        print('SIGNER: UNTRUSTED — archive was signed by a DIFFERENT key than you supplied')
        print('RESULT: INVALID — possible forgery (re-signed with an attacker key)')
        sys.exit(1)
    if not integrity_ok:
        print('RESULT: INVALID — archive failed integrity verification (records/anchor altered or missing)')
        sys.exit(1)
    if anchor_unchecked:
        print('RESULT: ANCHOR UNVERIFIED — this archive carries a transparency anchor you did')
        print('        not check. Re-run with --check-anchor <notary-fpr> (or --check-transparency).')
        sys.exit(2)
    print("SIGNER: UNVERIFIED — you did not supply --expect-key, so the signer's identity")
    print('        was not checked. Re-run with --expect-key <fingerprint>.')
    print('RESULT: INTEGRITY OK, SIGNER UNVERIFIED — data is internally consistent, but')
    print('        an attacker with write access could have re-signed. NOT fully verified.')
    sys.exit(2)