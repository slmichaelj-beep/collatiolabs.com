This archive opens with free tools and proves itself without any vendor.

  Open the data:   any SQLite tool on DEMO-CityPermitTracker.custodia.db
  Prove integrity: python3 verify.py DEMO-CityPermitTracker.custodia.db --expect-key 1e6fd5721e98fc4230f1a1fbe51b51b8aaa17cd24bcf97cd589f85c27cf7d8f9

verify.py has NO dependencies beyond Python 3. It recomputes every record
hash from the data, rebuilds the Merkle tree, and checks the Ed25519
signature on the completeness certificate.

TRUST ANCHOR — READ THIS. A signature only proves the payload was signed by
whatever key is stored in the archive. Anyone who can edit this file could
replace the data AND the signing key. To rule that out you MUST confirm the
signing key is genuinely Custodia's:

  Signing key fingerprint (this archive): 1e6fd5721e98fc4230f1a1fbe51b51b8aaa17cd24bcf97cd589f85c27cf7d8f9

Compare it to the fingerprint Custodia publishes independently (its website /
the signed paper certificate you were given). If they match, run the command
above and expect 'VALID'. If you run verify.py WITHOUT --expect-key it will
report 'SIGNER UNVERIFIED' by design — a self-consistent signature is not
proof of authorship. Do not trust a fingerprint that only appears inside this
bundle; obtain it from Custodia directly.
